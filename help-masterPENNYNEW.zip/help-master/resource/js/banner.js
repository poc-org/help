// JScript source code
var bannertext = '<div style="margin:0 auto; width:700px;position: relative; top: 0px; left: 0px; padding-left: 0px; background-color: #000000">'
bannertext += '\n<img src="https://raw.githubusercontent.com/lpenny22/help/master/resource/images/dxcuniversityhelpOrig2.jpg">'
bannertext += '\n</div> '
document.write(bannertext);

