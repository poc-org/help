// JScript source code
var headertext = '<div style="margin:0 auto; width:700px; position: relative; top: 0px; left: 0px; padding-left: 0; background-color: #000000">'
headertext += '\n<div style="margin:0 auto; width:700px; position:relative;top:10px;left:0px;padding-left:20;background-color:#000000" >'
headertext += '\n<img src="../resource/images/dxc_logo.jpg">'
headertext += '\n</div> '
headertext += '\n<div style="margin:0 auto; width:600px; position:absolute;top:0px;left:100px;padding-left:0;background-color:#000000">'
headertext += '\n<h2 style="color:white;">DXC University</h3>'
headertext += '\n</div>'
headertext += '\n</div>'
document.write(headertext);

